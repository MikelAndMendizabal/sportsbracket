'use strict';

/**
 * @ngdoc function
 * @name sportsbracketApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the sportsbracketApp
 */
angular.module('sportsbracketApp')
  .controller('AboutCtrl', function ($scope) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
